/**
 * Custom icon
 */
const icon = {};

icon.uppercase =
	<svg xmlns="http://www.w3.org/2000/svg" height="300" width="300" version="1" viewBox="0 0 24 24"> <path d="M22,7.7h-4V19h-2.1V7.7H13V6h9V7.7z" /> <path d="M11,7.7H8V19H5.9V7.7H2V6h9V7.7z" /> </svg>;

export default icon;
