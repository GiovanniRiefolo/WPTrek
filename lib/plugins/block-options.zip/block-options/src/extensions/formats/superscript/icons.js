/**
 * Custom icon
 */
const icon = {};

icon.superscript =
	<svg viewBox="-85 -985 1024 1024" xmlns="http://www.w3.org/2000/svg" role="img" aria-hidden="true" focusable="false"><path aria-hidden="true" role="img" focusable="false" transform="scale(1, -1)" translate="(0, -960)" d="M768 754v-50h128v-64h-192v146l128 60v50h-128v64h192v-146zM676 704h-136l-188-188-188 188h-136l256-256-256-256h136l188 188 188-188h136l-256 256z"></path></svg>;
export default icon;
