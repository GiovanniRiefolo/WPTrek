# Fullscreen Display

**Display Cover and Image Blocks in Fullscreen** in just few clicks. This will give you option to display perfect hero section on your website without relying on other blocks plugin. Also available on Group and Media & Text blocks.

## How to make Cover Block fullscreen?

1. Make sure the block is selected and on **Full Width** alignment.
2. Under **Advanced** block panel toggle **Full Screen Height** option.

![Gutenberg block editor fullscreen cover blocks](https://cldup.com/uGE7x8uf-V.gif)