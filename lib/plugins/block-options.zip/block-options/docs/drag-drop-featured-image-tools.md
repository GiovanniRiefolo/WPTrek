# Drag and Drop Featured Image

Easily upload or change featured image on Gutenberg editor by dragging and dropping image on Featured Image sidebar panel.

![Gutenberg block editor drag and drop featured image](https://cldup.com/fGiTYQYGl9.gif)