# Transform (3) Empty Paragraphs to Spacer Block

Automatically transform three(3) consecutive empty paragraphs to spacer block.

![Gutenberg block editor transform empty paragraphs to spacer block](https://cldup.com/AMTTiF3-kl.gif)