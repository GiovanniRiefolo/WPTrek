# Toggle Title Visibility

Toggle title visibility easily if you do not want to show it on the frontend of your website.

## How to hide post/page title?

Hide post or page title using the instructions below.

1. Click **Document** under editor sidebar settings.
2. Click **Hide Title** to make it hidden on your website.

![Gutenberg block editor hide title](https://cldup.com/SHdMt5ZOKh.gif)