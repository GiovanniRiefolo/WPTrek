# Media and Text Block Card Layout

Additional two(2) Media & Text block layouts. You will have card layout options with image above or below. This will give you better media with text implementation specially on narrow container like columns.

### How to change Media and Text Block to card layout?

Easily change apply card layout to Media & Text block using the steps below.

1. Select the Media and Text Block.
2. On the block toolbar you will have additional layouts to choose from.

![Gutenberg block editor media and text card layout](https://cldup.com/ZuK-OHg6RT.gif)