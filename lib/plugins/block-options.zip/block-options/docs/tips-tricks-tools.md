# Help, Tips and Tricks

EditorsKit provides **accessible help, tips and tricks** to help you navigate easily and save time on learning the new Gutenberg block editor through tips and tricks.

# How to access help, tips and tricks?

You can access help, tips and tricks at the bottom right side of the Gutenberg block editor with **? icon**.

![Gutenberg block editor help tips and tricks](https://cldup.com/Vhy3DPSvH1.gif)