# User State Visibility

Show or hide blocks only on **logged-in or logged-out** users.

## How to hide block on logged-in users?

1. Select the block you wanted to show or hide on specific devices.
2. Under **Advanced** block panel you can manage per user logged-in state.

![Gutenberg block editor hide block on loggedin users](https://cldup.com/LrRRbDxv1n.gif)