# Justified Paragraph Alignment

**Justify** is missing on paragraph alignment by default on Gutenberg block editor. Using EditorsKit, this alignment will be added via format on block toolbar.

## How make paragraph align justify?

Follow few steps below to easily align paragraph to justify.

![Gutenberg block editor justify paragraph alignment](https://cldup.com/Ee9rV7ems8.gif)

1. Make sure that you are on the paragraph block.
2. Click the caret icon on the block toolbar to open more rich text controls.
3. Click **Justify**. That's it!