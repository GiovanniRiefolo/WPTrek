# Nonbreaking Space

Easily insert nonbreaking space `&nbsp;` which will help you better format your content specially on phone numbers, price and more.

## How add nonbreaking space?

You can easily add nonbreaking space by following the steps below.

![Gutenberg block editor add nonbreaking space](https://cldup.com/3zXhzyY0kp.gif)

1. Click where you want the nonbreaking space to be inserted.
2. Click the caret icon on the block toolbar to open more rich text controls.
3. Click **Nonbreaking Space**. That's it!