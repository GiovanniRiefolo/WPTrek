# Copy Selected Block(s)

Easily copy selected single or multiple blocks. You can paste the copied items into any Gutenberg block editor.

## How to copy single or multiple blocks?

Here are the steps on how to copy blocks on Gutenberg editor.

1. Click single block or highlight multiple blocks.
2. Click the dots icon on the block toolbar to open more options.
3. Click **Copy**. That's it!

![Gutenberg block editor copy single or multiple blocks](https://cldup.com/6Q9bgNevDr.gif)