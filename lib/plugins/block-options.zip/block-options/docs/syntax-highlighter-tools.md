# Code Editor Syntax Highlighter

Apply the missing **Code Syntax Highlighter** when on code editor mode. This functionality utilizes the core WordPress codemirror library that you are used to when editing themes or plugins so there's no external library added.

![Gutenberg block editor code editors syntax highlighter](https://cldup.com/J0lRdk8oZ7.gif)