# Markdown

Easily apply formats while writing using markdowns. The following markdown shortcuts will automatically be converted on specific text formatting.

- `*bold*`
- `_italic_`
- `~strikethrough~`
- <code>&grave;code&grave;</code>

![Gutenberg block editor markdown formatting shortcuts](https://cldup.com/ApZLizFCDG.gif)