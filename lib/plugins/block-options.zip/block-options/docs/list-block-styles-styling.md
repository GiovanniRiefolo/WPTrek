# List Block Styles

EditorsKit comes with selection of styles on List Block for custom bullet icons such as **arrow**, **checked**, **crossed**, **connected dots** and **starred**.

![Gutenberg block editor list block styles](https://cldup.com/SvrhcBarqk.gif)