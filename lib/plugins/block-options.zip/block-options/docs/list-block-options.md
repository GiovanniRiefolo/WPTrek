# List Block Additional Settings

EditorsKit provides the missing **Font Size** and **Text Color** settings to list block.

### How to change List Block font size & text color?

Follow the few steps below to easily change list block's font size and text color.

![Gutenberg block editor list block settings](https://cldup.com/RPH1E74a_A.gif)

1. Make sure that the list block is selected.
2. Under the Block settings panel, you can change font size on **Text Settings**
2. Under the Block settings panel, you can change text color on **Color Settings**