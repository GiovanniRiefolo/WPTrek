# Image & Cover Block Styles

EditorsKit comes with selection of styles on Cover and Image Block for custom shapes; and layouts such as **diagonal**, **circular** and **rounder corners**; and even add **drop shadows**.

![Gutenberg block editor image and cover block styles](https://cldup.com/UebVGo2Gn5.gif)