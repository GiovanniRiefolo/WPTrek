# Set Image Block as Featured Image

Easily set selected image block as featured image on your post or page. This will save you few clicks and will let you replace featured image at ease.

## How to set image block as featured image?

Follow the steps below to set image block as featured image.

![Gutenberg block editor set image block as featured image](https://cldup.com/uKTzfKxBLi.gif)

1. Select the Image Block you want to set as featured image.
2. Click the dots icon to open more block options.
3. Click **Set as Featured Image**.