<?php

namespace WebPExpress;

class ValidateException extends \Exception
{
}
